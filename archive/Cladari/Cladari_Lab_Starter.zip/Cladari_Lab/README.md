# Cladari_Lab – Local AI + Bio Intelligence Starter

Welcome to your Cladari_Lab environment. This folder structure is built to support the Cladari platform's MVP – including plant lineage tracking, voice-AI interactions (Numina), DNA log enrichment, and live dashboard functionality.

---

## Setup Instructions

### 1. Clone or extract the folder to your Mac Studio

Place the `Cladari_Lab` folder anywhere local (e.g. ~/Projects/Cladari).

### 2. Install Required Tools

Ensure the following tools are installed:

- **Python 3.10+**
- **Whisper.cpp** – for offline speech-to-text
- **Mac TTS** or **Coqui TTS** – for AI voice output
- **Ollama** or **LM Studio** – to run Mistral, DeepSeek, etc.
- **ChromaDB or FAISS** – for vector memory
- **Flask** – for the local dashboard

### 3. Model Setup

```bash
brew install ollama
ollama pull mistral
ollama pull deepseek-coder
ollama pull phi
ollama pull qwen:7b
```

### 4. Run the Voice Loop

```bash
python main_loop.py
```

This launches Numina. Speak your plant care notes or ask for insights.

### 5. Launch Local Dashboard

```bash
cd app
python dashboard.py
```

Access the interface at `http://localhost:5000`

---

## Folder Guide

- `data/` – plant logs, DNA matches, audio/image entries
- `app/` – Flask dashboard + modules
- `models/` – LLM config
- `embeddings/` – vector search store
- `static/` / `templates/` – dashboard UI
- `README.md` – this file

---

## Future Integration

- GenBank + GBIF API syncs
- Image-to-log with CLIP
- Numina memory & tone tracking
- Inter-agent learning engine

---

Built for local sovereignty, biological clarity, and AI-powered conservation.

Truth lives here.

